
document.getElementById('image').addEventListener("onchange", function(){
  alert("asd");
    convert_to_base64();
});
function convert_to_base64(){
  var c = document.createElement('canvas');
  var ctx = c.getContext('2d');
  var img = document.getElementById('image');
  ctx.drawImage(img, 10, 10);
  var base64String = c.toDataURL();
  document.getElementById('image2').src=base64String;
};
